Nan = float('nan')
print(type(Nan))